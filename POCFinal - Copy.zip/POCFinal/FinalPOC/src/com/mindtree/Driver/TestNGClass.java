package com.mindtree.Driver;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.mindtree.Util.ExcelUtil;

	public class TestNGClass {

		
		
		
		@BeforeMethod(groups={"All"})
		public void pre()
		{
			
			Reporter.log(" Testcase execution starts here");
		}
		@Test
		public void Run() throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
		{
		String filePath= "./TestData/Scenarios.xlsx";
		String sc_sheet = "scenarios";
		int sc_count=0;
		try {
			sc_count = ExcelUtil.getRowCount(filePath, sc_sheet);
		} catch (EncryptedDocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(int i=1;i<sc_count;i++)
		{
			String cellvalue= ExcelUtil.getCellValue(filePath, sc_sheet, i, 1);
			if(cellvalue.equalsIgnoreCase("yes"))
			{
				String currentSc_name = ExcelUtil.getCellValue(filePath, sc_sheet, i, 0);
				String methodname = "get"+currentSc_name;
				
				try {
					OneWay.class.getMethod(methodname).invoke(null);
				} catch (NoSuchMethodException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SecurityException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				
			}
		}
		
		}
		
		@AfterMethod(groups={"All"})
		public void post()
		{
			//driver.quit();
			Reporter.log(" Testcase execution ends here");
		}
		
	}


