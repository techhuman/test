package com.mindtree.Driver;


	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;

	public class PageObjectClass {

		public PageObjectClass(WebDriver wdriver) {
			PageFactory.initElements(wdriver, this);
		}

		@FindBy(id = "oneWay")
		public WebElement OneWay;

		@FindBy(id = "flyFrom")
		public WebElement From;

		@FindBy(id = "flyTo")
		public WebElement To;

		@FindBy(xpath = ".//*[@id='searchForm']/fieldset[3]/div/div/div/div/p[1]/span/button")
		public WebElement DepDateIcon;
		
		@FindBy(xpath = "html/body/div[2]/table[1]/tbody/tr/td[3]")
		public WebElement DateNext;

		@FindBy(className = "dp_daypicker")
		public WebElement Daypicker;

		@FindBy(id = "txtDepartureDate")
		public WebElement DptDate;
		
		@FindBy(id = "dateFlex")
		public WebElement DateFlex;
		
		@FindBy(id = "adultNumber")
		public WebElement Adults;

		@FindBy(id = "childNumber")
		public WebElement Children;

		@FindBy(id = "infantNumber")
		public WebElement Infants;

		@FindBy(id = "search")
		public WebElement ShowFlights;
		
		@FindBy(xpath=".//*[@id='search-again']/div/div/div/div/div/table/tbody/tr/td[1]")
		public WebElement imgverify;
		
		@FindBy(xpath=".//*[@id='pageWrap']/div[2]/div[1]/div/div/div/div/h3/strong")
		public WebElement error;
		
		@FindBy(xpath=".//*[@id='tabs']/li[1]/a")
		public WebElement OneDayView;
		
		
		@FindBy(xpath=".//*[@id='btnSearchAgain']")
		public WebElement ModifyFlight;
		
		@FindBy(xpath=".//*[@id='flyFrom_1']")
		public WebElement ModifyFlight_FlyFrom;
		
		@FindBy(xpath=".//*[@id='flyTo_1']")
		public WebElement ModifyFlight_FlyTo;
		
		@FindBy(xpath=".//*[@id='form0']/fieldset[1]/div/div/div/div/p/span[2]/span/button")
				public WebElement ModifyFlightdate;
		@FindBy(xpath=".//*[@id='form0']/p/span/input")
		public WebElement ShowFlight_Modify;
		
		@FindBy(xpath=".//*[@id='segment1']/div[1]/div/h3")
		public WebElement verifytitle;
		
		@FindBy(xpath=".//*[@id='segment1']/div[1]/div/p[2]/a")
		public WebElement NextButton;
		
		@FindBy(xpath=".//*[@id='rbPayToChangeConnection_1_1']")
		public WebElement PaytoChangeRadioButton;
		
		@FindBy(xpath=".//*[@id='continueBtn']")
		public WebElement ContinueBtn;
		
		@FindBy(xpath=".//*[@id='fareUpsell']/div/div/div[2]/div/form/fieldset/p[1]/span/input")
		public WebElement PopupContinue;
		
		
		@FindBy(xpath=".//*[@id='PassengerDetailsFormModel_Passengers_0__Title']")
		public WebElement Title;
		
		@FindBy(xpath=".//*[@id='PassengerDetailsFormModel_Passengers_0__FirstName']")
		public WebElement Firstname;
		
		@FindBy(xpath=".//*[@id='PassengerDetailsFormModel_Passengers_0__LastName']")
		public WebElement Lastname;
		
		@FindBy(xpath=".//*[@id='PassengerDetailsFormModel_Passengers_0__Email']")
		public WebElement Email;
		
		@FindBy(xpath=".//*[@id='PassengerDetailsFormModel_Passengers_0__Country']")
		public WebElement Country;
		
		@FindBy(xpath=".//*[@id='PassengerDetailsFormModel_Passengers_0__HomeNumber_CountryCode']")
		public WebElement HomeNumberCountryCode;
		
		@FindBy(xpath=".//*[@id='PassengerDetailsFormModel_Passengers_0__HomeNumber_Phone']")
		public WebElement HomePhone;
		
		@FindBy(xpath=".//*[@id='PassengerDetailsFormModel_Passengers_0__MobileNumber_CountryCode']")
		public WebElement MobileCountryCode;
		
		@FindBy(xpath=".//*[@id='PassengerDetailsFormModel_Passengers_0__MobileNumber_Phone']")
		public WebElement MobileNumber;
		
		@FindBy(xpath=".//*[@id='PassengerDetailsFormModel_Passengers_1__Title']")
		public WebElement childTitle;
		
		@FindBy(xpath=".//*[@id='PassengerDetailsFormModel_Passengers_1__FirstName']")
		public WebElement ChildFirstName;
		
		@FindBy(xpath=".//*[@id='PassengerDetailsFormModel_Passengers_1__LastName']")
		public WebElement ChildLastName;
		
		@FindBy(xpath=".//*[@id='PassengerDetailsFormModel_Passengers_1__DateOfBirth_Day']")
		public WebElement ChildDOBDay;
		
		@FindBy(xpath=".//*[@id='PassengerDetailsFormModel_Passengers_1__DateOfBirth_Month']")
		public WebElement ChildDOBMonth;
		
		@FindBy(xpath=".//*[@id='PassengerDetailsFormModel_Passengers_1__DateOfBirth_Year']")
		public WebElement ChildDOBYear;
		
		@FindBy(xpath=".//*[@id='PassengerDetailsFormModel_Passengers_2__Title']")
		public WebElement InfantTitle;
		
		@FindBy(xpath=".//*[@id='PassengerDetailsFormModel_Passengers_2__FirstName']")
		public WebElement InfantFirstName;
		
		@FindBy(xpath=".//*[@id='PassengerDetailsFormModel_Passengers_2__LastName']")
		public WebElement InfantLastName;
		
		@FindBy(xpath=".//*[@id='PassengerDetailsFormModel_Passengers_2__DateOfBirth_Day']")
		public WebElement InfantDOBDay;
		
		@FindBy(xpath=".//*[@id='PassengerDetailsFormModel_Passengers_2__DateOfBirth_Month']")
		public WebElement InfantDOBMonth;
		
		@FindBy(xpath=".//*[@id='PassengerDetailsFormModel_Passengers_2__DateOfBirth_Year']")
		public WebElement InfantDOBYear;
		
		@FindBy(xpath=".//*[@id='OptionalExtrasFormModel_No_InsuranceRequiredAllPassengers']")
		public WebElement NoInsurance;
		
		@FindBy(xpath=".//*[@id='modalBaggageUpsell']/div[2]/div/p[1]/span/a")
		public WebElement LastContinuebtn;
		
		@FindBy(xpath=".//*[@id='termsConditions']")
		public WebElement TermsandConditions;
		
		@FindBy(xpath=".//*[@id='stylingForm']/fieldset/p[3]/span/span[2]/span/a")
		public WebElement paylaterbtn;
		
		
		
		
		
		
		
		
		
	
}

	



