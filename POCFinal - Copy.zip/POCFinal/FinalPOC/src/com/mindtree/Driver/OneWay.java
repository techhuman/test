package com.mindtree.Driver;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.*;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Reporter;

import com.mindtree.Util.*;

public class OneWay {

	static Logger logger = Logger.getLogger("TestNGClass");
    static int i=0;
	static WebDriver driver = new FirefoxDriver();
	static PageObjectClass page = new PageObjectClass(driver);
	static String filePath = "./TestData/Data.xlsx";
	static String data_sheet = "one_way";
	static String URL = ExcelUtil.getCellValue(filePath, data_sheet, 1, 0);
	
	

	public static void getone_way() {

		try {
			PropertyConfigurator.configure("Log4j.properties");
			driver.get("http://www.flydubai.com");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			getDetails();
			getScreenshot();

			Thread.sleep(2000);

			try 
			{
				if (page.error.isDisplayed())
				{
					System.out.println("No Select Flight page displayed");
					getDetails();
				}
			} catch (WebDriverException e) {}

			try 
			{
				page.PaytoChangeRadioButton.click();
				Thread.sleep(3000);

				page.ContinueBtn.click();
				Thread.sleep(3000);

				page.PopupContinue.click();
				Thread.sleep(3000);

			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}

			try {
				page.Title.sendKeys(ExcelUtil
						.RExcel(filePath, data_sheet, 1, 8));
				page.Firstname.sendKeys(ExcelUtil.RExcel(filePath, data_sheet,
						1, 9));
				page.Lastname.sendKeys(ExcelUtil.RExcel(filePath, data_sheet,
						1, 11));
				page.Email.sendKeys(ExcelUtil.RExcel(filePath, data_sheet, 1,
						12));
				page.Country.sendKeys(ExcelUtil.RExcel(filePath, data_sheet, 1,
						13));
				page.HomeNumberCountryCode.sendKeys(ExcelUtil.RExcel(filePath,
						data_sheet, 1, 14));
				page.HomePhone.sendKeys(ExcelUtil.RExcel(filePath, data_sheet,
						1, 15));
				page.MobileCountryCode.sendKeys(ExcelUtil.RExcel(filePath,
						data_sheet, 1, 16));
				page.MobileNumber.sendKeys(ExcelUtil.RExcel(filePath,
						data_sheet, 1, 17));
				page.childTitle.sendKeys(ExcelUtil.RExcel(filePath, data_sheet,
						1, 18));
				page.ChildFirstName.sendKeys(ExcelUtil.RExcel(filePath,
						data_sheet, 1, 19));
				page.ChildLastName.sendKeys(ExcelUtil.RExcel(filePath,
						data_sheet, 1, 20));
				page.ChildDOBDay.sendKeys(ExcelUtil.RExcel(filePath,
						data_sheet, 1, 21));
				page.ChildDOBMonth.sendKeys(ExcelUtil.RExcel(filePath,
						data_sheet, 1, 22));
				page.ChildDOBYear.sendKeys(ExcelUtil.RExcel(filePath,
						data_sheet, 1, 23));
				page.InfantTitle.sendKeys(ExcelUtil.RExcel(filePath,
						data_sheet, 1, 24));
				page.InfantFirstName.sendKeys(ExcelUtil.RExcel(filePath,
						data_sheet, 1, 25));
				page.InfantLastName.sendKeys(ExcelUtil.RExcel(filePath,
						data_sheet, 1, 26));
				page.InfantDOBDay.sendKeys(ExcelUtil.RExcel(filePath,
						data_sheet, 1, 27));
				page.InfantDOBMonth.sendKeys(ExcelUtil.RExcel(filePath,
						data_sheet, 1, 28));
				page.InfantDOBYear.sendKeys(ExcelUtil.RExcel(filePath,
						data_sheet, 1, 29));
				Thread.sleep(1000);
				page.ContinueBtn.click();
				Thread.sleep(3000);
				page.NoInsurance.click();
				Thread.sleep(3000);
				page.ContinueBtn.click();
				Thread.sleep(3000);
				page.LastContinuebtn.click();
				Thread.sleep(3000);
				page.paylaterbtn.click();
				Thread.sleep(3000);
				page.TermsandConditions.click();
				Thread.sleep(3000);
				page.ContinueBtn.click();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		    } catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void getScreenshot() {
		// TODO Auto-generated method stub
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		// Now you can do whatever you need to do with it, for example copy somewhere
		String scr= "";
		try {
		scr = new SimpleDateFormat("yyyyMMddhhmm'.txt'").format(new Date());
		String screen="./Results/Screenshots/"+scr+"_screenshot.png";
			FileUtils.copyFile(scrFile, new File(screen));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void getDetails() {

		page.OneWay.click();
		logger.info("One way is selected");
		getScreenshot();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e3) {
			// TODO Auto-generated catch block
			e3.printStackTrace();
		}
		page.From.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		page.From.clear();
		getScreenshot();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e3) {
			// TODO Auto-generated catch block
			e3.printStackTrace();
		}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		page.From.sendKeys(ExcelUtil.getCellValue(filePath, data_sheet, 1, 2));
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		page.From.sendKeys(Keys.TAB);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Reporter.log("From is given as KTM", true);
		getScreenshot();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e3) {
			// TODO Auto-generated catch block
			e3.printStackTrace();
		}
		page.To.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		page.To.sendKeys(ExcelUtil.getCellValue(filePath, data_sheet, 1, 3));
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		page.To.sendKeys(Keys.TAB);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Reporter.log("To is given as RUH", true);

		page.DepDateIcon.click();
		try {
			for (int i = 0; i <= 5; i++) {
				page.DateNext.click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			}
			Calendar cal = Calendar.getInstance();
			int today = cal.get(Calendar.DAY_OF_MONTH);
			List<WebElement> tableRows = page.Daypicker.findElements(By
					.tagName("tr"));
			for (int i = 1; i < tableRows.size(); i++) {
				for (int j = 0; j < 7; j++) {
					if (Integer.parseInt(tableRows.get(i)
							.findElements(By.tagName("td")).get(j).getText()) == today)
						tableRows.get(i).findElements(By.tagName("td")).get(j)
								.click();

				}

			}
		} catch (NumberFormatException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String ad = "";
		try {
			ad = ExcelUtil.RExcel(filePath, data_sheet, 1, 5);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		page.Adults.sendKeys(ad);
		String ch = "";
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		try {
			ch = ExcelUtil.RExcel(filePath, data_sheet, 1, 6);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		page.Children.sendKeys(ch);
		String in = "";
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		try {
			in = ExcelUtil.RExcel(filePath, data_sheet, 1, 7);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		page.Infants.sendKeys(in);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		System.out.println("before");
		driver.manage().window().maximize();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		page.ShowFlights.click();
		System.out.println("after");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}
}
