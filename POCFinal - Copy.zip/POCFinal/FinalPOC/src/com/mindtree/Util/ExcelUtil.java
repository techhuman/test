package com.mindtree.Util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;




//import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtil {

	public static String getCellValue(String filePath, String sheetName,
			int row, int column) {

		Workbook excelBook = getWorkBook(filePath);
		Sheet s = getSheetWithName(excelBook, sheetName);
		return (String) getCellValue(s, row, column);

	}

	public static int getRowCount(String filePath, String sheetname)
			throws EncryptedDocumentException, InvalidFormatException,
			IOException {
	
		Workbook excelBook = getWorkBook(filePath);
		Sheet sheet = excelBook.getSheet(sheetname);
		return sheet.getLastRowNum();

	}

	public static Workbook getWorkBook(String filePath) {

		if (null != filePath) {
			// String extension = filePath.substring(filePath.indexOf("."));

			FileInputStream fis;
			Workbook wb;
			try {
				fis = new FileInputStream(filePath);
				//String extn = filePath.substring(, -1);
				String ext= filePath.substring(filePath.length()-3);
				String extn=filePath.substring(filePath.length()-4);
						if (ext.equalsIgnoreCase("xls")) {
					  wb = new HSSFWorkbook(fis);
					} else if(extn.equalsIgnoreCase("xlsx")) {
					  wb = new XSSFWorkbook(fis);
					} else {
					  throw new IllegalArgumentException("Received file does not have a standard excel extension.");
					}
				return wb;

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (EncryptedDocumentException e) {
				e.printStackTrace();
			}

		}

		return null;
	}

	/**
	 * To get the sheet from the given workbook with the specified name
	 * 
	 * @param excelBook
	 * @param sheetName
	 * @return
	 */
	public static Sheet getSheetWithName(Workbook excelBook, String sheetName) {

		if (null != excelBook) {

			return excelBook.getSheet(sheetName);
		}
		return null;
	}

	public static Object getCellValue(Sheet sheet, int rowNumber,
			int columnNumber) {

		if (null != sheet) {

			Row row = sheet.getRow(rowNumber);

			Cell cel = row.getCell(columnNumber);
			return getCellValue(cel, cel.getCellType());
		}
		return null;
	}

	private static Object getCellValue(Cell cell, int cellType) {

		switch (cellType) {
		case Cell.CELL_TYPE_NUMERIC:

			return cell.getNumericCellValue();

		case Cell.CELL_TYPE_STRING:

			return cell.getStringCellValue();

		case Cell.CELL_TYPE_FORMULA:

			return cell.getCellFormula();

		case Cell.CELL_TYPE_BOOLEAN:

			return cell.getBooleanCellValue();

		case Cell.CELL_TYPE_ERROR:

			cell.getErrorCellValue();

		default:

			System.out.println("no cell type found");
			return null;
		}

	}
	public static String RExcel(String path,String SheetName, int row,int col) throws IOException
	{
		
	FileInputStream fis=new FileInputStream(new File(path));
	XSSFWorkbook wb= new XSSFWorkbook (fis);
	
	Sheet sheet= wb.getSheet(SheetName);
	if(sheet!=null)
		{
		DataFormatter formatter = new DataFormatter(); 
		
	 Cell cell = sheet.getRow(row).getCell(col);
	 String s=formatter.formatCellValue(cell);
		
	 return s;
		}
	else
	{
		throw new IllegalArgumentException("No sheet exists with name " + SheetName);
	}
	//return sheet.getRow(row).getCell(col).getStringCellValue();
	
	}
}